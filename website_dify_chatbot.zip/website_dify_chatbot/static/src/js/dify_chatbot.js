/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";

publicWidget.registry.DifyChatbotLoader = publicWidget.Widget.extend({
  selector: "body", // run on all website pages

  start() {
    this._super(...arguments);

    // chatbot config
    window.difyChatbotConfig = {
      token: "5sEPV0Y8ZNynnsDB", // 🔑 your token
      baseUrl: "http://dify.fadoo.ir:8080", // 🌍 your base URL
    };

    // load script dynamically
    const script = document.createElement("script");
    script.src = "http://dify.fadoo.ir:8080/embed.min.js";
    script.defer = true;
    script.id = "5sEPV0Y8ZNynnsDB";
    document.body.appendChild(script);
  },
});
