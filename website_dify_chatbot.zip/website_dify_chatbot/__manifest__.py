{
    'name': 'Website Dify Chatbot',
    'version': '16.0.1.0.0',
    'summary': 'Embed Dify Chatbot on all website pages',
    'category': 'Website',
    'author': 'Mostafa',
    'depends': ['website'],
    'assets': {
        'web.assets_frontend': [
            'website_dify_chatbot/static/src/js/dify_chatbot.js',
            'website_dify_chatbot/static/src/css/dify_chatbot.css',
        ],
    },
    'installable': True,
    'application': False,
    'auto_install': False,
}
